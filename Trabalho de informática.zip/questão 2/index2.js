let N1= 8
let N2= 6
let N3= 8
let N4= 7
let media = (N1 + N2 + N3 + N3)/ 4
if (media>= 9.0){document.write("parabéns você tirou A, sua média é: " + media + " e você foi aprovado (a)")}
else if (media >= 7.5 & media < 9.0 ){
  document.write("parabéns você tirou B, sua média é: " + media + " e você foi aprovado(a)")
}
else if (media >= 6.0 & media < 7.5 ){
  document.write("parabéns você tirou C, sua média é: " + media + " e você foi aprovado(a)")
}
else if (media < 9.0 ){
  document.write("Sinto muito... você tirou D, sua média é: " + media + " e você foi Reprovado(a)")
}

