
console.log("<strong>Ordem crescente:</strong>")
for(let number = 1 ; number <= 10 ; number++){
  console.log(`<strong>${number}</strong>`);
  
}
console.log("<strong>Ordem decrescente:</strong>")
for(let number2 = 10 ; number2 >= 1 ; number2--){
  console.log(`<strong>${number2}</strong>`);
  
}