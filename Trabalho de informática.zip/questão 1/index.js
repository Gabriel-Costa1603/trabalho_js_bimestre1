let valorum = 11
if(valorum > 10){
  document.write("o valor é maior que 10... o valor é: " + valorum)
}
else if(valorum = 10){ document.write("o valor é igual a 10")
}
else if(valorum < 10){
  document.write("valor é meno que 10... o valor é: "+ valorum)
}

