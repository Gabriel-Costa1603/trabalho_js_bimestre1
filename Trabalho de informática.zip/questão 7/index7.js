
let number = 101;

while(number <= 110){
  console.log(`<strong>${number}<strong>`);
  number++;
  
}
