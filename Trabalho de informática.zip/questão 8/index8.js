
let N = 10;

for(let x = 1; x <= N; x++){
  console.log(`<strong>${x}</strong>`)
}
